package servidor.model;

import java.util.HashMap;

/**
* Classe para sessoes de telefonia
*/
public class TabelaHash {
    /**
     * sessoes é um HashMap com chave celular e conteúdo sendo dados da sessao
     */
    public HashMap<String, Sessao> sessoes;
    
    public TabelaHash() {
        sessoes = new HashMap<>();
    }
}
