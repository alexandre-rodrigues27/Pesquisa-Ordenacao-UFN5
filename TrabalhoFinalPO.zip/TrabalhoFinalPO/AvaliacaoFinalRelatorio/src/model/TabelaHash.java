/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.HashMap;

public class TabelaHash {
    public HashMap<String,Produto> produtos;

    public TabelaHash() {
        produtos = new HashMap<>();
    }
}