/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.List;
import model.Produto;

/**
 *
 * @author laboratorio
 */
public class Pesquisa {
    public static Produto buscaLinearPorId(List<Produto> lista, int id) {
        for (Produto p : lista) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }
    
    public static Produto buscaBinariaPorId(List<Produto> listaOrdenadaPorId, int id) {
        int esquerda = 0;
        int direita = listaOrdenadaPorId.size() - 1;

        while (esquerda <= direita) {
            int meio = esquerda + (direita - esquerda) / 2;
            int idMeio = listaOrdenadaPorId.get(meio).getId();

            if (idMeio == id) {
                return listaOrdenadaPorId.get(meio);
            } else if (idMeio < id) {
                esquerda = meio + 1;
            } else {
                direita = meio - 1;
            }
        }
        return null;
    }

}
