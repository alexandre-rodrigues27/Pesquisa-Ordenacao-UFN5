package controller;

import java.util.Comparator;
import java.util.List;
import model.Produto;

public class Ordenacao {

    // Comparadores prontos
    public static final Comparator<Produto> POR_ID =
            Comparator.comparingInt(Produto::getId);

    public static final Comparator<Produto> POR_NOME =
            Comparator.comparing(Produto::getNome, String.CASE_INSENSITIVE_ORDER);

    public static final Comparator<Produto> POR_PRECO =
            Comparator.comparingDouble(Produto::getPreco);

    // Bubble Sort 
    public static boolean bolha(List<Produto> lista, Comparator<Produto> comp, long timeoutNs) {
        final long inicio = System.nanoTime();
        int limite = lista.size() - 1;
        boolean trocou = true;

        while (trocou) {
            if (estourouTempo(inicio, timeoutNs)) {
                return false;
            }

            trocou = false;
            for (int i = 0; i < limite; i++) {
                if (comp.compare(lista.get(i), lista.get(i + 1)) > 0) {
                    trocar(lista, i, i + 1);
                    trocou = true;
                }
            }
            limite--;
        }
        return true;
    }

    private static boolean estourouTempo(long inicio, long timeoutNs) {
        return timeoutNs > 0 && (System.nanoTime() - inicio) > timeoutNs;
    }

    // Quick Sort
    public static void quickSort(List<Produto> lista, Comparator<Produto> comp) {
        if (lista == null || lista.size() < 2) return;
        ordenar(lista, 0, lista.size() - 1, comp);
    }

    private static void ordenar(List<Produto> lista, int esq, int dir, Comparator<Produto> comp) {
        if (esq >= dir) return;
        int p = particionar(lista, esq, dir, comp);
        ordenar(lista, esq, p - 1, comp);
        ordenar(lista, p + 1, dir, comp);
    }

    private static int particionar(List<Produto> lista, int esq, int dir, Comparator<Produto> comp) {
        trocar(lista, esq + (dir - esq) / 2, dir); // pivô do meio vai para o fim
        Produto pivo = lista.get(dir);

        int menores = esq - 1;
        for (int j = esq; j < dir; j++) {
            if (comp.compare(lista.get(j), pivo) <= 0) {
                trocar(lista, ++menores, j);
            }
        }
        trocar(lista, menores + 1, dir);
        return menores + 1;
    }

    private static void trocar(List<Produto> lista, int a, int b) {
        Produto tmp = lista.get(a);
        lista.set(a, lista.get(b));
        lista.set(b, tmp);
    }
}