package util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import model.Produto;

public class Util {

    private static final String SEPARADOR = ";";
    private static final int COLUNAS_MINIMAS = 5;

    public static boolean carregarArquivosEmLista(String nomeArquivo, ArrayList<Produto> listaDestino) {
        if (listaDestino == null) {
            return false;
        }

        try (BufferedReader leitor = new BufferedReader(
                new FileReader(nomeArquivo, StandardCharsets.UTF_8))) {

            leitor.readLine(); // descarta o cabeçalho

            String linha;
            while ((linha = leitor.readLine()) != null) {
                if (linha.isBlank()) continue;

                String[] campos = linha.split(SEPARADOR);
                if (campos.length < COLUNAS_MINIMAS) continue;

                Produto produto = criarProduto(campos);
                if (!listaDestino.contains(produto)) {
                    listaDestino.add(produto);
                }
            }
            return true;

        } catch (IOException | NumberFormatException e) {
            System.err.println("Ocorreu algum erro: " + e.getMessage());
            return false;
        }
    }

    private static Produto criarProduto(String[] campos) {
        int id = Integer.parseInt(campos[0].trim());
        String nome = campos[1].trim();
        String categoria = campos[2].trim();
        double preco = Double.parseDouble(campos[3].trim().replace(",", "."));
        int estoque = Integer.parseInt(campos[4].trim());
        return new Produto(id, nome, categoria, preco, estoque);
    }
}