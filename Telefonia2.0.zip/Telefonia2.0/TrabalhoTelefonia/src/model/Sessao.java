package model;

import java.util.Objects;

public class Sessao {
    String nmrCelular;
    String dadosSessao;

    public Sessao(String nmrCelular, String dadosSessao) {
        this.nmrCelular = nmrCelular;
        this.dadosSessao = dadosSessao;
    }

    public String getNumeroCelular() {
        return nmrCelular;
    }

    public void setNumeroCelular(String nmrCelular) {
        this.nmrCelular = nmrCelular;
    }

    public String getDadosSessao() {
        return dadosSessao;
    }

    public void setDadosSessao(String dadosSessao) {
        this.dadosSessao = dadosSessao;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 41 * hash + Objects.hashCode(this.nmrCelular);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Sessao other = (Sessao) obj;
        return Objects.equals(this.nmrCelular, other.nmrCelular);
    }

    @Override
    public String toString() {
        return "Sessao{" + "nmrCelular=" + nmrCelular + ", dadosSessao=" + dadosSessao + '}';
    }
}