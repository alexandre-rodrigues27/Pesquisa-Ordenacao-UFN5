package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import model.Sessao;

public class Util {

    public static String carregarArquivoEmHashMap(String nomeArquivo, HashMap<String, Sessao> sessoes, StringBuilder dadosSessoes) {
        sessoes.clear();
        dadosSessoes.setLength(0);

        try (BufferedReader leitor = Files.newBufferedReader(Paths.get(nomeArquivo), StandardCharsets.UTF_8)) {
            String linha;
            while ((linha = leitor.readLine()) != null) {
                dadosSessoes.append(linha).append(System.lineSeparator());

                String[] campos = linha.split(";");
                if (campos.length >= 2) {
                    Sessao sessao = new Sessao(campos[0].trim(), campos[1].trim());
                    sessoes.put(sessao.getNumeroCelular(), sessao);
                }
            }
            return "";
        } catch (IOException e) {
            return "Erro ao processar o arquivo: " + e.getMessage();
        }
    }
}